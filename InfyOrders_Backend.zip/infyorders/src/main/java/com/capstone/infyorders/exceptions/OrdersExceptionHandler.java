package com.capstone.infyorders.exceptions;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class OrdersExceptionHandler extends ResponseEntityExceptionHandler	 {
	@ExceptionHandler(OrderNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleException(OrderNotFoundException e) {
	    return new ResponseEntity<>( new ErrorMessage(e.getMessage(), LocalDateTime.now()), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(OrderNotCreatedException.class)
	public ResponseEntity<ErrorMessage> handleException(OrderNotCreatedException e) {
	    return new ResponseEntity<>( new ErrorMessage(e.getMessage(), LocalDateTime.now()), HttpStatus.BAD_REQUEST);
	}
}

