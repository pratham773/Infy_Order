package com.capstone.infyorders.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.capstone.infyorders.entity.OrderItems;
import com.capstone.infyorders.entity.Orders;
import com.capstone.infyorders.entity.Products;
/**
 * ==================================================================================
 * Data Transfer Object For Sending Orders Data with OrderItems and Products
 * ==================================================================================
 *
 */
public class OrderDTO {
	private Long id;
	private Timestamp createdAt;
	private Timestamp updatedAt;
	private int numOfProducts;
	private String shippingTo;
	private int total;
	private int userId;
	private List<OrderItems> orderItems;
	private List<Products> productDetails;
	
	public OrderDTO() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getNumOfProducts() {
		return numOfProducts;
	}

	public void setNumOfProducts(int numOfProducts) {
		this.numOfProducts = numOfProducts;
	}

	public String getShippingTo() {
		return shippingTo;
	}

	public void setShippingTo(String shippingTo) {
		this.shippingTo = shippingTo;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public List<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}

	public List<Products> getProductDetails() {
		return productDetails;
	}

	public void setProductDetails(List<Products> productDetails) {
		this.productDetails = productDetails;
	}

	public OrderDTO(Long id, Timestamp createdAt, Timestamp updatedAt, int numOfProducts, String shippingTo, int total,
			int userId, List<OrderItems> orderItems, List<Products> productDetails) {
		super();
		this.id = id;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.numOfProducts = numOfProducts;
		this.shippingTo = shippingTo;
		this.total = total;
		this.userId = userId;
		this.orderItems = orderItems;
		this.productDetails = productDetails;
	}

	@Override
	public String toString() {
		return "OrderDTO [id=" + id + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + ", numOfProducts="
				+ numOfProducts + ", shippingTo=" + shippingTo + ", total=" + total + ", userId=" + userId
				+ ", orderItems=" + orderItems + ", productDetails=" + productDetails + "]";
	}

	public static OrderDTO prepareDTO(Orders order) {
		// TODO Auto-generated method stub
		OrderDTO orderDto = new OrderDTO();
		orderDto.setId(order.getId());
		orderDto.setCreatedAt(order.getCreatedDate());
		orderDto.setNumOfProducts(order.getNumOfProducts());
		orderDto.setShippingTo(order.getShipping_to());
		orderDto.setTotal(order.getTotal());
		orderDto.setUpdatedAt(order.getUpdatedDate());
		orderDto.setUserId(order.getUserId());
		return orderDto;
	}

	public static Orders prepareEntity(OrderDTO order) {
		// TODO Auto-generated method stub
		Orders orders = new Orders();
		orders.setUserId(order.getUserId());
		orders.setNumOfProducts(order.getNumOfProducts());
		orders.setShipping_to(order.getShippingTo());
		orders.setTotal(order.getTotal());
		return orders;
		}

	public static List<OrderItems> prepareOrderItemsEntity(OrderDTO order) {
		// TODO Auto-generated method stub
		List<OrderItems> orderItem  = new ArrayList<OrderItems>();
		orderItem = order.getOrderItems();
		return orderItem;
	}	
		
	
}
