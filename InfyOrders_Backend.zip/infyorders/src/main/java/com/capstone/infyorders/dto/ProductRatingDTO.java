package com.capstone.infyorders.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import com.capstone.infyorders.entity.ProductsFeedback;
/**
 * ==================================================================================
 * Data Transfer Object For Receiving ProductRatings
 * ==================================================================================
 *
 */
public class ProductRatingDTO {
	private Long productId;
	private int rating;
	private String feedback;
	private Long userId;
	private Long orderId;
	
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public ProductRatingDTO(Long productId, int rating, String feedback, Long userId, Long orderId) {
		super();
		this.productId = productId;
		this.rating = rating;
		this.feedback = feedback;
		this.userId = userId;
		this.orderId = orderId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getFeedback() {
		return feedback;
	}


	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}



	public Long getUserId() {
		return userId;
	}



	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public ProductRatingDTO() {
		
	}

	public static ProductsFeedback prepareEntity(ProductRatingDTO product) {
		// TODO Auto-generated method stub
		ProductsFeedback feedback = new ProductsFeedback();
		feedback.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
		feedback.setFeedback(product.getFeedback());
		feedback.setRating(product.getRating());
		feedback.setProductId(product.getProductId());
		feedback.setUserId(product.getUserId());
		feedback.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
		
		return feedback;
		
	}
	
}
