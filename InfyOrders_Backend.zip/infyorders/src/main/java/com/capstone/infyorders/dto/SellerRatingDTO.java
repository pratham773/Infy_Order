package com.capstone.infyorders.dto;

import com.capstone.infyorders.entity.SellerFeedback;
/**
 * ==================================================================================
 * Data Transfer Object For Receiving SellerRatings
 * ==================================================================================
 *
 */
public class SellerRatingDTO {
	private Long sellerId;
	private int rating;
	private String feedback;
	private Long userId;
	private Long orderId;
	private Long productId;
	
	public SellerRatingDTO() {
		
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getProductId() {
		return productId;
	}


	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public SellerRatingDTO(Long sellerId, int rating, String feedback, Long userId, Long orderId, Long productId) {
		super();
		this.sellerId = sellerId;
		this.rating = rating;
		this.feedback = feedback;
		this.userId = userId;
		this.orderId = orderId;
		this.productId = productId;
	}

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public Long getUserId() {
		return userId;
	}


	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public static SellerFeedback prepareEntity(SellerRatingDTO seller) {
		// TODO Auto-generated method stub
		SellerFeedback feedback = new SellerFeedback();
		feedback.setFeedback(seller.getFeedback());
		feedback.setRating(seller.getRating());
		feedback.setSellerId(seller.getSellerId());
		feedback.setUserId(seller.getUserId());
		return feedback;
	}
	
	
	
	
}
