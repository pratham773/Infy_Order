package com.capstone.infyorders.dto;
/**
 * ==================================================================================
 * Data Transfer Object For Updating OrderItems status
 * ==================================================================================
 *
 */
public class StatusDTO {
	private int statusCode;
	private Long productId;
	private Long orderID;
	public StatusDTO(int statusCode, Long productId, Long orderID) {
		super();
		this.statusCode = statusCode;
		this.productId = productId;
		this.orderID = orderID;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Long getOrderID() {
		return orderID;
	}
	public void setOrderID(Long orderID) {
		this.orderID = orderID;
	}
	
}
