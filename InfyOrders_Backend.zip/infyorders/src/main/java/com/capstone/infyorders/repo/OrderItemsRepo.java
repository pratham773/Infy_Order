package com.capstone.infyorders.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstone.infyorders.entity.OrderItems;

import java.util.*;
/**
 * ======================================================================
 * OrderItems Repository
 *=======================================================================
 */
@Repository
public interface OrderItemsRepo  extends JpaRepository<OrderItems, Long> {
	List<OrderItems> findByOrderId(Long orderId);
	
	List<OrderItems> findBySellerId(int sellerId);

	
	@Query("SELECT o FROM OrderItems o WHERE orderId = :orderId AND productId = :productId")
    OrderItems findByOrderIdAndProductId(@Param("orderId") Long orderId, @Param("productId") Long productId);


}
