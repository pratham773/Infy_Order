package com.capstone.infyorders.entity;

import java.sql.Timestamp;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;


/**
 * ====================================================================================
 *  Entity for Orders
 * ====================================================================================
 */

@Entity
public class Orders {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	private Long id;
	
	private Integer userId;
	private Integer total;
	private Integer numOfProducts;
	private String shipping_to;
	@CreatedDate
	private Timestamp createdDate;
	
	@LastModifiedDate
	private Timestamp updatedDate;

	@Override
	public String toString() {
		return "Orders [id=" + id + ", userId=" + userId + ", total=" + total + ", numOfProducts=" + numOfProducts
				+ ", shipping_to=" + shipping_to + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ "]";
	}

	public Orders(Long id, Integer userId, Integer total, Integer numOfProducts, String shipping_to,
			Timestamp createdDate, Timestamp updatedDate) {
		super();
		this.id = id;
		this.userId = userId;
		this.total = total;
		this.numOfProducts = numOfProducts;
		this.shipping_to = shipping_to;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getNumOfProducts() {
		return numOfProducts;
	}

	public void setNumOfProducts(Integer numOfProducts) {
		this.numOfProducts = numOfProducts;
	}

	public String getShipping_to() {
		return shipping_to;
	}

	public void setShipping_to(String shipping_to) {
		this.shipping_to = shipping_to;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	public Orders() {
		
	}
	
	
}
