package com.capstone.infyorders.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * ====================================================================================
 *  Entity for Seller Information
 * ====================================================================================
 */
@Entity
public class SellerFeedback {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private Long sellerId;
	private int rating;
	private String feedback;
	private Long UserId;
		
	public SellerFeedback() {
		
	}

	

	public SellerFeedback(Long id, Long sellerId, int rating, String feedback, Long userId) {
		super();
		this.id = id;
		this.sellerId = sellerId;
		this.rating = rating;
		this.feedback = feedback;
		UserId = userId;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}



	public Long getUserId() {
		return UserId;
	}



	public void setUserId(Long userId) {
		UserId = userId;
	}

	
	
	
}
