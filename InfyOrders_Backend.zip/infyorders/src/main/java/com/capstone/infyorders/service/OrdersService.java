package com.capstone.infyorders.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.infyorders.dto.OrderDTO;
import com.capstone.infyorders.dto.ProductRatingDTO;
import com.capstone.infyorders.dto.SellerRatingDTO;
import com.capstone.infyorders.dto.StatusDTO;
import com.capstone.infyorders.entity.OrderItems;
import com.capstone.infyorders.entity.Orders;
import com.capstone.infyorders.entity.Products;
import com.capstone.infyorders.exceptions.OrderNotCreatedException;
import com.capstone.infyorders.exceptions.OrderNotFoundException;
import com.capstone.infyorders.repo.OrderItemsRepo;
import com.capstone.infyorders.repo.OrdersRepo;
import com.capstone.infyorders.repo.ProductsFeedbackRepository;
import com.capstone.infyorders.repo.ProductsRepo;
import com.capstone.infyorders.repo.SellerFeedbackRepo;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 * ================================================================================
 * 	Service For Infy Orders
 * ================================================================================
 */
@Service
public class OrdersService {
	
	@Autowired
	private OrdersRepo orderRepo;
	
	@Autowired
	private OrderItemsRepo orderItemsRepo;
	
	@Autowired
	private ProductsRepo productRepo;
	
	@Autowired
	private ProductsFeedbackRepository productFeedbackRepo;
	
	@Autowired
	private SellerFeedbackRepo sellerFeedbackRepo;
	
	/**
	 * ===================================================================
	 *  Get Orders By UserId
	 *  Return a list of OrderDTO
	 *  Throws OrderNotFoundException
	 * ===================================================================
	 * @param userId
	 * @return
	 */
	@HystrixCommand(fallbackMethod="getOrderByUserIdFallback",ignoreExceptions= {OrderNotFoundException.class})
	public List<OrderDTO> getOrderByUserId(int userId) {
		List<Orders> order = this.orderRepo.findByUserId(userId);
		List<OrderDTO> orderDtoList = new ArrayList<OrderDTO>();
		if(order.isEmpty()) {
			throw new OrderNotFoundException("No Orders Found For The User");
		}
		for(Orders ord: order) {
			List<Products> products= new ArrayList<Products>();
			OrderDTO orderDto =  OrderDTO.prepareDTO(ord);
			List<OrderItems> orderItems = this.orderItemsRepo.findByOrderId(orderDto.getId());
			if(orderItems.isEmpty()) {
				throw new OrderNotFoundException("No Order Items Found For The User");
			}
			for(OrderItems items: orderItems) {
		        LocalDateTime now = LocalDateTime.now();
		        long noOfDaysBetween = ChronoUnit.DAYS.between(items.getDeliveryDate().toLocalDate(), now);
		        System.out.println(noOfDaysBetween);
		        if(items.getStatus() == 3 && noOfDaysBetween < 30 && items.getProductReviewEligible() == 1) {
		        	items.setProductReviewEligible(1);
		        }
		        else {
		        	items.setProductReviewEligible(0);
		        }
		        if(items.getStatus() == 3 && noOfDaysBetween < 30 && items.getSellerReviewEligible() == 1) {
		        	items.setSellerReviewEligible(1);
		        }
		        else {
		        	items.setSellerReviewEligible(0);
		        }
		        if(items.getStatus() == 1) {
		        	items.setCancelEligible(1);
		        }
		        else {
		        	items.setCancelEligible(0);
		        }
		        if(items.getStatus() == 3 && noOfDaysBetween < 10) {
		        	items.setReturnEligible(1);
		        }
		        else {
		        	items.setReturnEligible(0);
		        }
		        items.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
		        this.orderItemsRepo.save(items);
			}
			orderDto.setOrderItems(orderItems);
			for(OrderItems orderItem: orderDto.getOrderItems()) {
				
				/**
       			1. Contacting the microservice of Product Module
 	   			2. To Fetch the corresponding Product Details
	   			3. String url = http://localhost:9000/product/getProductDetailsByProductId/{id}
	   			4. Map<String, String> params = new HashMap<>();
	   			5. vars.put("id", orderItem.getProductId());
       	    	6. new RestTemplate().getForEntity(url,Products.class,"1");
				 */				
				Optional<Products>  product = this.productRepo.findById(orderItem.getProductId());
				if(product.isPresent()) {
					Products prod = product.get();
					products.add(prod);
				}
				else {
					throw new OrderNotFoundException("Product doesnt exists");
				}
			}
			orderDto.setProductDetails(products);
			orderDtoList.add(orderDto);
		}
		return orderDtoList;
	}
	
	/**
	 * ==================================================================
	 * Fallback for getOrderByUserId
	 * ==================================================================
	 * @param userId
	 * @return
	 */
	public List<OrderDTO> getOrderByUserIdFallback(int userId) {
		throw new RuntimeException("Server is Currently Unavailable. Please try again Later");
	}
	
	/**
	 * ===================================================================
	 *  Create an Order and Odd OrderItems
	 *  Return a Success Message on completion
	 *  Throws OrderNotCreatedException
	 * ===================================================================
	* @param userId
	 * @param orders
	 * @return
	 */
	@HystrixCommand(fallbackMethod="createOrderFallback")
	public String createOrder(int userId, OrderDTO orders) {
		Orders order= OrderDTO.prepareEntity(orders);
		List<OrderItems> items = OrderDTO.prepareOrderItemsEntity(orders);
		OrderDTO result = OrderDTO.prepareDTO(orderRepo.save(order));
		for(OrderItems item: items) {
			item.setOrderId(result.getId());
			this.orderItemsRepo.save(item);
		}
		return "Order Created Successfully";
	}
	
	/**
	 * ===================================================================
	 *  Fallback For Create Order
	 * ===================================================================
	 * @param userId
	 * @param orders
	 * @return
	 */
	public String createOrderFallback(int userId, OrderDTO orders) {
		throw new OrderNotCreatedException("Order was not created");
	}
	
	/**
	 * ===================================================================
	 *  Update Status of an Order Item
	 *  Throws OrderNotFoundException
	 * =================================================================== 
	 * @param status
	 * @return
	 */
	@HystrixCommand(fallbackMethod="updateStatusFallback",ignoreExceptions= {OrderNotFoundException.class})
	public String updateStatus(StatusDTO status) {
		OrderItems order = this.orderItemsRepo.findByOrderIdAndProductId(status.getOrderID(), status.getProductId());
		if(order == null) {
			throw new OrderNotFoundException("No Order Items Found For the given Order and productId");
		}
		order.setStatus(status.getStatusCode());
		if(status.getStatusCode() != 1) {
			order.setCancelEligible(0);
		}
		if(status.getStatusCode() != 3) {
			order.setReturnEligible(0);
		}
		if(status.getStatusCode() == 3) {
			order.setDeliveryDate(LocalDateTime.now());
		}
		order.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
		this.orderItemsRepo.save(order);
		return "Status Updated Successfully";
	}
	
	/**
	 * ===================================================================
	 *  Fallback for update Status
	 * =================================================================== 
	 * @param status
	 * @return
	 */
	public String updateStatusFallback(StatusDTO status) {
		throw new RuntimeException("Failed to update Status of the order item");
	}
	
	/**
	 * ===================================================================
	 *  Update Feedback For Products
	 *  Throws Product/Order Not Found Exception
	 * =================================================================== 
	 * @param product
	 * @return
	 */
	@HystrixCommand(fallbackMethod="updateProductFeedbackFallback",ignoreExceptions= {OrderNotFoundException.class})
	public String updateProductFeedback(ProductRatingDTO product) {
		 OrderItems order = this.orderItemsRepo.findByOrderIdAndProductId(product.getOrderId(), product.getProductId());
		 if(order == null) {
			 throw new OrderNotFoundException("Order Item Not Found");
		 }
		 /**
			1. Contacting the microservice of Product Module
 			2. To Save/Send the corresponding Product Details
			3. String url = http://localhost:9000/product/feedback
			4. new RestTemplate.postForEntity(uri, ProductRatingDTO.prepareEntity(product), ProductsFeedback.class);
		*/	 
		 order.setProductReviewEligible(0);
		 order.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
		 this.orderItemsRepo.save(order);
		 this.productFeedbackRepo.saveAndFlush(ProductRatingDTO.prepareEntity(product));
		 return "Product Feedback was Submitted";
	}
	
	/**
	 * ===================================================================
	 *  Fallback for updateProductFeedback
	 * =================================================================== 
	 * @param product
	 * @return
	 */
	public String updateProductFeedbackFallback(ProductRatingDTO product) {
		throw new RuntimeException("Product feeback submission failed");
	}
	
	
	/**
	 * ===================================================================
	 *  Update Feedback of Sellers
	 *  Throws OrderNotFoundException
	 * =================================================================== 
	 * @param seller
	 * @return
	 */
	@HystrixCommand(fallbackMethod="updateSellerFeedbackFallback",ignoreExceptions= {OrderNotFoundException.class})
	public String updateSellerFeedback(SellerRatingDTO seller) {
		 OrderItems order = this.orderItemsRepo.findByOrderIdAndProductId(seller.getOrderId(), seller.getProductId());
		 if(order == null) {
			 throw new OrderNotFoundException("Order Item Not Found");
		 }
		 /**
			1. Contacting the microservice of Seller Module
 			2. To Save/Send the corresponding Seller Details
			3. String url = http://localhost:9000/seller/feedback
			4. new RestTemplate.postForEntity(uri, SellerRatingDTO.prepareEntity(seller), SellerFeedback.class);
		*/	
		 order.setSellerReviewEligible(0);
		 order.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
		 this.orderItemsRepo.save(order);
		 this.sellerFeedbackRepo.saveAndFlush(SellerRatingDTO.prepareEntity(seller));
		 return "Updated Seller Feedback";
	}
	
	/**
	 * ===================================================================
	 *  Fallback for updateProductFeedback
	 * =================================================================== 
	 * @param product
	 * @return
	 */
	public String updateSellerFeedbackFallback(SellerRatingDTO seller) {
		throw new RuntimeException("Seller Feedback not submitted");
	}
	
	/**
	 * ===================================================================
	 *  Get All orderItems based on SellerId
	 *  Throws OrderNotFoundException
	 * =================================================================== 
	 * @param sellerId
	 * @return
	 */
	public List<OrderItems> getOrderBySellerId(int sellerId) {
		List<OrderItems> orderItems = this.orderItemsRepo.findBySellerId(sellerId);
		if(orderItems.isEmpty()) {
			throw new OrderNotFoundException("Order Items Not Found");
		}
		return orderItems;
	}
	
}
	