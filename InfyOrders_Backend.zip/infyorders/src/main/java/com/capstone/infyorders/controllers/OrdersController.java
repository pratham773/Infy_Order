package com.capstone.infyorders.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.infyorders.dto.OrderDTO;
import com.capstone.infyorders.dto.ProductRatingDTO;
import com.capstone.infyorders.dto.SellerRatingDTO;
import com.capstone.infyorders.dto.StatusDTO;
import com.capstone.infyorders.entity.OrderItems;
import com.capstone.infyorders.service.OrdersService;

@CrossOrigin
@RestController
public class OrdersController {

	@Autowired
	private OrdersService service;
	/**
	 * =============================================================================
	 * Endpoint to get all orders and orderItems based on userId
	 * =============================================================================
	 * @param userId
	 * @return
	 */
	@CrossOrigin
	@GetMapping("/orders/{userId}")
	public ResponseEntity<List<OrderDTO>> getOrderByUserId(@PathVariable("userId") int userId) {
		return new ResponseEntity<>(this.service.getOrderByUserId(userId), HttpStatus.OK);
	}
	
	
	/**
	 * =============================================================================
	 * Endpoint to get all orderItems based on sellerId
	 * =============================================================================
	 * @param userId
	 * @return
	 */
	@CrossOrigin
	@GetMapping("/orders/seller/{sellerId}")
	public ResponseEntity<List<OrderItems>> getOrderBySellerId(@PathVariable("sellerId") int sellerId) {
		return new ResponseEntity<>(this.service.getOrderBySellerId(sellerId), HttpStatus.OK);
	}
	
	/**
	 * =============================================================================
	 * Endpoint to Create/Add Order and OrderItems
	 * =============================================================================
	 * @param userId
	 * @param order
	 * @return
	 */
	@CrossOrigin
	@PostMapping("/orders/{userId}")
	public ResponseEntity<String> createOrder(
			@PathVariable("userId") int userId, 
			@RequestBody OrderDTO order
			) {
		return new ResponseEntity<>(this.service.createOrder(userId, order), HttpStatus.OK);
	}
	
	/**
	 * =============================================================================
	 * Endpoint to update Status of an order Item
	 * =============================================================================
	 * @param status
	 * @return
	 */
	@CrossOrigin
	@PutMapping("/orders/status")
	public ResponseEntity<String> updateStatus(
			 @RequestBody StatusDTO status
			) {
		return new ResponseEntity<>(this.service.updateStatus(status), HttpStatus.OK);
	}
	
	/**
	 * =============================================================================
	 * Endpoint to create product Feedback Data for a particular productID
	 * =============================================================================
	 * @param product
	 * @return
	 */
	@CrossOrigin
	@PostMapping("/orders/productFeedback")
	public ResponseEntity<String> updateProductFeedback(
			 @RequestBody ProductRatingDTO product
			) {
		return new ResponseEntity<>(this.service.updateProductFeedback(product), HttpStatus.OK);
	}
	
	/**
	 * =============================================================================
	 * Endpoint to create seller Feedback Data for a particular productID
	 * =============================================================================
	 * @param product
	 * @return
	 */
	@CrossOrigin
	@PostMapping("/orders/sellerFeedback")
	public ResponseEntity<String> updateSellerFeedback(
			 @RequestBody SellerRatingDTO seller
			) {
		return new ResponseEntity<>(this.service.updateSellerFeedback(seller), HttpStatus.OK);
	}
	
}
