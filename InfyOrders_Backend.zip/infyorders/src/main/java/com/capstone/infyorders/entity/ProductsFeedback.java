package com.capstone.infyorders.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

/**
 * ====================================================================================
 *  Entity for Product Feedback
 * ====================================================================================
 */

@Entity
public class ProductsFeedback {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private Long productId;
	private Long userId;
	private Integer rating;
	private String feedback;
	
	@CreatedDate
	private Timestamp createdDate;
	
	@LastModifiedDate
	private Timestamp updatedDate;

	

	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public Long getProductId() {
		return productId;
	}



	public void setProductId(Long productId) {
		this.productId = productId;
	}



	public Long getUserId() {
		return userId;
	}



	public void setUserId(Long userId) {
		this.userId = userId;
	}



	public Integer getRating() {
		return rating;
	}



	public void setRating(Integer rating) {
		this.rating = rating;
	}



	



	public ProductsFeedback(Long id, Long productId, Long userId, Integer rating, String feedback,
			Timestamp createdDate, Timestamp updatedDate) {
		super();
		this.id = id;
		this.productId = productId;
		this.userId = userId;
		this.rating = rating;
		this.feedback = feedback;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
	}



	public Timestamp getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}



	public Timestamp getUpdatedDate() {
		return updatedDate;
	}



	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}



	public String getFeedback() {
		return feedback;
	}



	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}



	public ProductsFeedback() {
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public String toString() {
		return "ProductsFeedback [id=" + id + ", productId=" + productId + ", userId=" + userId + ", rating=" + rating
				+ ", feedback=" + feedback + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}
	
	
}
