package com.capstone.infyorders.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstone.infyorders.entity.ProductsFeedback;

/**
 * ======================================================================
 * Products Feedback Repository
 *=======================================================================
 */
@Repository
public interface ProductsFeedbackRepository extends JpaRepository<ProductsFeedback, Long> {

}
