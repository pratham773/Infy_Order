package com.capstone.infyorders.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capstone.infyorders.entity.SellerFeedback;

/**
 * ======================================================================
 * Seller Feedback Repository
 *=======================================================================
 */
@Repository
public interface SellerFeedbackRepo extends JpaRepository<SellerFeedback, Long> {

}
