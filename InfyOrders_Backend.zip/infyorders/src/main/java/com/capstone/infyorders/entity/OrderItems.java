package com.capstone.infyorders.entity;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

/**
 * ====================================================================================
 *  Entity for Order Items
 * ====================================================================================
 */

@Entity
public class OrderItems {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;

	private Long orderId;
	private Integer quantity;
	private Long productId;
	private Integer price;
	private Integer status;
	private LocalDateTime deliveryDate;
	private int returnEligible;
	private int cancelEligible;
	private int productReviewEligible;
	private int sellerReviewEligible;
	private int sellerId;
	private String sellerName;
	
	@CreatedDate
	private Timestamp createdDate;
	
	@LastModifiedDate
	private Timestamp updatedDate;
	
	public OrderItems() {
		
	}

	

	public OrderItems(Long id, Long orderId, Integer quantity, Long productId, Integer price, Integer status,
			LocalDateTime deliveryDate, int returnEligible, int cancelEligible, int productReviewEligible,
			int sellerReviewEligible, int sellerId, String sellerName, Timestamp createdDate, Timestamp updatedDate) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.quantity = quantity;
		this.productId = productId;
		this.price = price;
		this.status = status;
		this.deliveryDate = deliveryDate;
		this.returnEligible = returnEligible;
		this.cancelEligible = cancelEligible;
		this.productReviewEligible = productReviewEligible;
		this.sellerReviewEligible = sellerReviewEligible;
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public LocalDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(LocalDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public int getReturnEligible() {
		return returnEligible;
	}

	public void setReturnEligible(int returnEligible) {
		this.returnEligible = returnEligible;
	}

	public int getCancelEligible() {
		return cancelEligible;
	}

	public void setCancelEligible(int cancelEligible) {
		this.cancelEligible = cancelEligible;
	}

	public int getProductReviewEligible() {
		return productReviewEligible;
	}

	public void setProductReviewEligible(int productReviewEligible) {
		this.productReviewEligible = productReviewEligible;
	}

	public int getSellerReviewEligible() {
		return sellerReviewEligible;
	}

	public void setSellerReviewEligible(int sellerReviewEligible) {
		this.sellerReviewEligible = sellerReviewEligible;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	

	public String getSellerName() {
		return sellerName;
	}



	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}



	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "OrderItems [id=" + id + ", orderId=" + orderId + ", quantity=" + quantity + ", productId=" + productId
				+ ", price=" + price + ", status=" + status + ", deliveryDate=" + deliveryDate + ", returnEligible="
				+ returnEligible + ", cancelEligible=" + cancelEligible + ", productReviewEligible="
				+ productReviewEligible + ", sellerReviewEligible=" + sellerReviewEligible + ", sellerId=" + sellerId
				+ ", sellerName=" + sellerName + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}
	
	
	
}
