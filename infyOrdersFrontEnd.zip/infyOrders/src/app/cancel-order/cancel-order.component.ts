import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-cancel-order',
  templateUrl: './cancel-order.component.html',
  styleUrls: ['./cancel-order.component.css']
})
export class CancelOrderComponent implements OnInit {
  state:any;
  productDetails:any;
  orderItems: any;
  errorMessage: any;

  constructor(private router: Router,private route: ActivatedRoute, private service: OrdersService) {
    this.state = this.router.getCurrentNavigation()?.extras.state;
    this.productDetails = this.state.productDetails;
    this.orderItems = this.state.orderDetails;
  }

  ngOnInit(): void {
  }
  /**
   * ==================================================================
   * Cancel The Order
   * ==================================================================
   */
  confirmCancel(){
    this.service.changeOrderStatus(-2,this.productDetails.id,this.orderItems.orderId)
    .subscribe(response=>{
      this.router.navigate(['/orders']);
    }, (error)=>{
      console.log(error);
      this.errorMessage = "Order wasnt Cancelled. Please try again later";
    });
  }
}
