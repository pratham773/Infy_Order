import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { OrdersService } from '../orders.service';


@Component({
  selector: 'app-seller-review',
  templateUrl: './seller-review.component.html',
  styleUrls: ['./seller-review.component.css']
})
export class SellerReviewComponent implements OnInit {
  reviewForm: any;
  starSelected: any;
  productDetails:any;
  orderItems: any;
  state: any;
  errorMessage: any;

  constructor( private fb: FormBuilder, private router: Router,private route: ActivatedRoute, private service: OrdersService) { 
    this.state = this.router.getCurrentNavigation()?.extras.state;
    this.productDetails = this.state.productDetails;
    this.orderItems = this.state.orderDetails;
    this.reviewForm = this.fb.group({
      review: ['', [Validators.required]],    
    });
    this.starSelected = 1;
  }

  ngOnInit(): void {
  }  

  stars(value: any){
    this.starSelected = value;

  }

  reviewSubmit(){
    this.service.sendOrderSellerFeedback(this.productDetails['id'], this.starSelected, this.reviewForm.value.review, 1, this.orderItems['orderId'],this.orderItems['sellerId'])
    .subscribe(response=>{
      this.router.navigate(['/orders']);
    }, (error)=>{
      this.errorMessage = "Review was not submitted. Please try again later";
    });
  }

}

