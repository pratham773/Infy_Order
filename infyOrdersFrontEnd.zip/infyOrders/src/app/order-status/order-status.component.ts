import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-order-status',
  templateUrl: './order-status.component.html',
  styleUrls: ['./order-status.component.css']
})
export class OrderStatusComponent implements OnInit {
  statusForm: any;
  errorMessage: any;
  constructor(private formBuilder: FormBuilder, private service: OrdersService,private router: Router) { }

  ngOnInit(): void {
    this.statusForm = this.formBuilder.group({
      productId: ['', Validators.required],
      orderId: ['', [Validators.required]],    
      statusCode: ['',Validators.required]
  });
  }

  statusChange(){
    this.service.changeOrderStatus(this.statusForm?.value.statusCode,this.statusForm?.value.orderId,this.statusForm?.value.productId)
    .subscribe(response=>{
      this.router.navigate(['/orders']);
    }, (error)=>{
      console.log(error);
      this.errorMessage = "Order status was not changed. Please try again later";
    });
  }

}
