import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrdersComponent } from './orders/orders.component';
import { NavbarComponent } from './navbar/navbar.component';
import { OrdersService } from './orders.service';
import { HttpClientModule } from '@angular/common/http';
import { OrderTrackingComponent } from './order-tracking/order-tracking.component';
import { CancelOrderComponent } from './cancel-order/cancel-order.component';
import { ReturnOrderComponent } from './return-order/return-order.component';
import { OrderStatusComponent } from './order-status/order-status.component';
import { ProductReviewComponent } from './product-review/product-review.component';
import { SellerReviewComponent } from './seller-review/seller-review.component';
import { SecurityComponent } from './security/security.component';
import { JwtClientService } from './jwt-client.service';
import { LoaderComponent } from './loader/loader.component';

@NgModule({
  declarations: [
    AppComponent,
    OrdersComponent,
    NavbarComponent,
    OrderTrackingComponent,
    CancelOrderComponent,
    ReturnOrderComponent,
    OrderStatusComponent,
    ProductReviewComponent,
    SellerReviewComponent,
    SecurityComponent,
    LoaderComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [OrdersService, JwtClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
