import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-order-tracking',
  templateUrl: './order-tracking.component.html',
  styleUrls: ['./order-tracking.component.css']
})
export class OrderTrackingComponent implements OnInit {
  productDetails:any;
  orderItems: any;
  status: number;
  statusMessage: string;
  state: any;
  cancel:number;
  return: number;
  

  constructor(private router: Router,private route: ActivatedRoute, private service: OrdersService) {
    this.state = this.router.getCurrentNavigation()?.extras.state;
    this.productDetails = this.state.productDetails;
    this.orderItems = this.state.orderDetails;
    this.status = this.orderItems.status;
    this.statusMessage = 'Cancel';
    this.cancel =-2;
    this.return=-4;
  }

  ngOnInit(): void {
  }

  /**
   * =========================================================
   * Redirect on status change
   * -2: Cancel The Order And Initiate Refund 
   * -4: Return The Order And Initiate Refund
   * =========================================================
   * @param code 
   */
  changeStatus(code: number){
    if(code === -2){
      this.router.navigate(['/ordersTracking/cancel'], {state: this.state, skipLocationChange: true, replaceUrl: false});  
    }
    if(code === -4){
      this.router.navigate(['/ordersTracking/return'], {state: this.state, skipLocationChange: true, replaceUrl: false});  
    }
  }

  /**
   * =========================================================
   * To check if the product is elgible for cancel 
   * =========================================================
   * @returns 
   */
  cancelEligibility(){
    if(this.orderItems.cancelEligible === 1){
      return true;
    }
    return false;
  }

  /**
   * =========================================================
   * To check if the product is eligible for return 
   * =========================================================
   * @returns 
   */
  returnEligibility(){
    if(this.orderItems.returnEligible === 1){
      return true;
    }
    return false;
  }

  /**
   * =========================================================
   * Get StatusMessage Base On The Status Code 
   * =========================================================
   * @param code 
   * @returns 
   */
    getStatus(code: number){
      return this.service.getStatus(code);
    }

    productReviewEligibility(){
      if(this.orderItems.productReviewEligible === 1){
        return true;
      }
      return false;
    }

    sellerReviewEligibility(){
      if(this.orderItems.sellerReviewEligible === 1){
        return true;
      }
      return false;
    }

    changeReview(type: String){
      if(type==="product"){
        this.router.navigate(['/orders/productReview'], {state: this.state, skipLocationChange: true, replaceUrl: false});
      }
      else if(type==="seller"){
        this.router.navigate(['/orders/sellerReview'], {state: this.state, skipLocationChange: true, replaceUrl: false});
        
      }
    }
}
