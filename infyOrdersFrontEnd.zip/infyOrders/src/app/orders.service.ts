import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { JwtClientService } from './jwt-client.service';
  

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  constructor(private http: HttpClient, private authService: JwtClientService) {  }

  /**
   * =========================================================
   * API call to fetch all orders of the user 
   * =========================================================
   * @returns 
   */
  getAllOrders(){
    let token = "Bearer " + this.authService.getToken();
    return this.http.get("http://localhost:8765/infyorders/orders/1");
  }

  /**
   * =================================================================
   * Api call to change the order status ( Cancel / Return)
   * =================================================================
   * @param statusCode 
   * @param productId 
   * @param orderID 
   * @returns 
   */
  changeOrderStatus(statusCode: number, productId: number, orderID: number){
    let statusObject = {
      statusCode: statusCode,
      productId: productId,
      orderID: orderID
    };

    return this.http.put("http://localhost:8765/infyorders/orders/status", statusObject,{responseType: 'text'});

  }

    /**
   * =========================================================
   * Get StatusMessage Base On The Status Code 
   * =========================================================
   * @param code 
   * @returns 
   */
    getStatus(code: number){

      switch(code) { 
        case 1: 
          return "Open";
          break; 
        
        case 2: { 
          return "Shipped";
          break; 
        }
  
        case 3: { 
          return "Delivered";
          break; 
        }
  
        case -2: { 
          return "Cancelled and Refund Initiated";
          break; 
        }
  
        case -3: { 
          return "Cancelled and Refunded";
          break; 
        }
  
        case -4: { 
          return "Return and Refund Status Initiated";
          break; 
        }
  
        case -5: { 
          return "Returned and Refunded";
          break; 
        }
  
        default: { 
          return "Not Available";
          break; 
        }
        
      }
    }

    sendOrderItemFeedback(productId: any, rating: any, feedback: any, userId: any, orderId: any){
      let feedbackObject = {
      productId: productId,
	    rating: rating,
	    feedback: feedback,
	    userId: userId,
	    orderId: orderId
      };
  
      return this.http.post("http://localhost:8765/infyorders/orders/productFeedback", feedbackObject,{responseType: 'text'});  
    }

    sendOrderSellerFeedback(productId: any, rating: any, feedback: any, userId: any, orderId: any, sellerId: any){
      let feedbackObject = {
      productId: productId,
	    rating: rating,
	    feedback: feedback,
	    userId: userId,
	    orderId: orderId,
      sellerId: sellerId
      };
  
      return this.http.post("http://localhost:8765/infyorders/orders/sellerFeedback", feedbackObject,{responseType: 'text'});  
    }

}
