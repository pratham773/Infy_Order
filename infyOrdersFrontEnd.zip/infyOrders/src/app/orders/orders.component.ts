import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtClientService } from '../jwt-client.service';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  response: any;
  error:any;
  categories: any;
  statuses: any;
  categorySelected: Boolean;
  statusSelected: Boolean;
  selectedCategory: any = "";
  selectedStatus: any = "";
  loader: Boolean = true;

  
  constructor( private service: OrdersService, private router: Router, private authService: JwtClientService ) {
      this.categories=[];
      this.statuses=[];
      this.categorySelected = false;
      this.statusSelected = false;
  }
  ngOnInit(): void {
    this.service.getAllOrders().subscribe((resp)=>{
      this.response = resp;
      for (let index = 0; index < this.response.length; index++) {
        this.response[index]['categories'] = [];
        this.response[index]['statuses'] = [];
        for(let product of this.response[index].productDetails){
          if(!(this.response[index].categories.includes(product.category))){
            this.response[index].categories.push(product.category);
            if(!(this.categories.includes(product.category))){
              this.categories.push(product.category);
            }
          }
        } 
        for(let order of this.response[index].orderItems){
          if(!(this.response[index].statuses.includes(order.status))){
            this.response[index].statuses.push(order.status);
            if(!(this.statuses.includes(order.status))){
              this.statuses.push(order.status);
            }
          }
        }        
      }
      console.log(this.response);
      this.loader = false;
    },(error)=>{
      this.error = error;
    });

    
  }

  /**
   * =========================================================
   * Track OrderItem Details On Click of View Details Button
   * =========================================================
   * @param productDetails 
   * @param orderDetails 
   */
  selectedData(productDetails: any, orderDetails: any){
    this.router.navigate(['/ordersTracking'], {state: {productDetails: productDetails, orderDetails: orderDetails}, skipLocationChange: true, replaceUrl: false});
  }

  /**
   * =========================================================
   * Get StatusMessage Base On The Status Code 
   * =========================================================
   * @param code 
   * @returns 
   */
  getStatus(code: number){
    return this.service.getStatus(code);
  }

  /**
   * =========================================================
   * To check if any category is selected in Filter By Categories 
   * =========================================================
   * @param id 
   */
  selectCategory(id: any){
    if(id.value == "0"){
      this.categorySelected = false;
      this.selectedCategory = 0;
    }
    else{
      this.categorySelected = true;
      this.selectedCategory = id.value;
    }
  }

  /**
   * =========================================================
   * To check if any status is selected in Filter By Status 
   * =========================================================
   * @param id 
   */
  selectStatus(id: any){
    if(id.value == "0"){
      this.statusSelected = false;
      this.selectedStatus = 0;
    }
    else{
      this.statusSelected = true;
      this.selectedStatus = parseInt(id.value);
    }
  }


  /**
   * =========================================================
   * Filter Orders based on Category or Status or Both
   * =========================================================
   * @returns 
   */
  filtering(order: any){
    if(!(this.statusSelected) && !(this.categorySelected)){
      return true;
    }
  
    if(this.categorySelected && !(this.statusSelected)){
      if(order.categories.includes(this.selectedCategory)){
        return true;
      }
    }

    else if(!(this.categorySelected) && this.statusSelected){
      if(order.statuses.includes(this.selectedStatus)){
        return true;
      }
    }

    else if(this.statusSelected && this.categorySelected){
      let res: Boolean = false;
      if(order.categories.includes(this.selectedCategory)){
        res = true;
      }
      else{
        res = false;
        return res;
      }
      if(order.statuses.includes(this.selectedStatus)){
        res = true;
      }
      else{
        res = false;
        return res;
      }

      return res;
    }

    return false;
  }


  /**
   * =========================================================
   * Filter Individual Products based on Category or Status or Both
   * =========================================================
   * @param product 
   * @param orderItem 
   */
  filterProduct(category: any, status: any){
    if(!(this.statusSelected) && !(this.categorySelected)){
      return true;
    }
  
    if(this.categorySelected && !(this.statusSelected)){
      if(category === this.selectedCategory){
        return true;
      }
    }

    else if(!(this.categorySelected) && this.statusSelected){
      if(status == this.selectedStatus){
        return true;
      }
    }

    else if(this.statusSelected && this.categorySelected){
      let res: Boolean = false;
      if(category === this.selectedCategory){
        res = true;
      }
      else{
        res = false;
        return res;
      }
      if(status == this.selectedStatus){
        res = true;
      }
      else{
        res = false;
        return res;
      }

      return res;
    }

    return false;
  }


}
