import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JwtClientService {
  token: any = "";
  constructor(private http: HttpClient) { }
  
  generateToken(request: any){
    return this.http.post("http://localhost:8100/authenticate", request);
  }

  setToken(token: any){
    this.token = token;
  }

  getToken(){
    return this.token;
  }

  welcome(token: any){
    let tokenStr="Bearer "+token;
    const headers = new HttpHeaders().set("Authorization", tokenStr);
    return this.http.get("http://localhost:8765/infyorders/authenticate", {headers, responseType:'text' as 'json'});
  }

}
