import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CancelOrderComponent } from './cancel-order/cancel-order.component';
import { OrderStatusComponent } from './order-status/order-status.component';
import { OrderTrackingComponent } from './order-tracking/order-tracking.component';
import { OrdersComponent } from './orders/orders.component';
import { ProductReviewComponent } from './product-review/product-review.component';
import { ReturnOrderComponent } from './return-order/return-order.component';
import { SecurityComponent } from './security/security.component';
import { SellerReviewComponent } from './seller-review/seller-review.component';

const routes: Routes = [
  {path: 'orders/sellerReview', component:SellerReviewComponent},
  {path: 'orders/productReview', component:ProductReviewComponent},
  {path: 'orders/status', component:OrderStatusComponent},
  {path: 'ordersTracking/return', component:ReturnOrderComponent},
  {path: 'ordersTracking/cancel', component:CancelOrderComponent},
  {path: 'ordersTracking', component:OrderTrackingComponent},
  {path: 'orders', component:OrdersComponent},
  {path: '**', redirectTo: 'orders', pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
