import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JwtClientService } from '../jwt-client.service';

@Component({
  selector: 'app-security',
  templateUrl: './security.component.html',
  styleUrls: ['./security.component.css']
})
export class SecurityComponent implements OnInit {

  loginForm: any;
  submitted = false;
  authRequest:any;
  errorMessage: any;
  token: any;

  constructor(private service: JwtClientService,private formBuilder: FormBuilder, private router: Router) {
    this.authRequest = {
      "username": "buyer",
      "password": "password"
    };
  }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['buyer@infosys.com', Validators.required],
      password: ['password', [Validators.required]],    
  });
  }

  onSubmit(){
    if(this.loginForm?.value.username==="buyer@infosys.com" && this.loginForm?.value.password==="password"){
      console.log("Submitted");
      this.router.navigate(['/orders']);
    }
    else{
      this.errorMessage = "Invalid Credentials";
    }
  }

}
